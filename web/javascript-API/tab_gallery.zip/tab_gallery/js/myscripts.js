function show_picture(imgs) {
  
}
