function show_picture(imgs) {
  alert("请修改源代码中的 js 文件实现图片展示效果。");

  // 定义一个变量，变量内容为
  // 调用 document.getElementById() 方法
  // 参数为元素 ID 为 expandedImg 用来显示大图


  // 定义一个变量，变量内容为
  // 调用 document.getElementById() 方法
  // 参数为元素 ID 为 imgtext 用来显示图标题


  // 获取被点击图片的src
  // 并将 expandedImg 的src字段赋值为被点击图片的src
  // 使得展示区域显示大图


  // 获取被点击图片的 alt 属性作为标题
  // 将其赋值为 imgText 元素的文本内容


  // 默认情况下展示区域是隐藏的
  // 修改展示区域 expandImg 父元素的diskplay 属性为block
  // 显示出大图

  
}
